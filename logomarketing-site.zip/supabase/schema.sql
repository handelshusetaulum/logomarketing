-- ============================================================
--  LogoMarketing – databaseskema
--  Kør hele filen i Supabase → SQL Editor → New query → Run.
--  Kan køres igen uden at ødelægge noget (idempotent).
-- ============================================================

create extension if not exists pgcrypto;

-- ---------- Hvem må se admin-data? ----------
create table if not exists public.admins (
  email text primary key,
  created_at timestamptz default now()
);
insert into public.admins (email) values ('info@logomarketing.dk') on conflict do nothing;

create or replace function public.is_admin()
returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.admins where lower(email) = lower(coalesce(auth.jwt() ->> 'email', '')));
$$;

-- ---------- Leads (forespørgsler fra formularen) ----------
create table if not exists public.leads (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  stage text not null default 'ny' check (stage in ('ny','kontakt','tilbud','vundet','tabt')),
  org text not null,
  name text not null,
  email text not null,
  phone text,
  event_name text,
  event_date date,
  color text,
  tent_qty int default 0,
  tent_size text,
  tent_walls int,
  items text[] default '{}',
  message text,
  sponsor text,
  logo_path text,
  est_value numeric default 0,
  notes text default '',
  follow_up date,
  source text default 'logomarketing.dk'
);
create index if not exists leads_stage_idx on public.leads (stage);
create index if not exists leads_created_idx on public.leads (created_at desc);

-- ---------- Aktivitetslog pr. lead ----------
create table if not exists public.lead_events (
  id bigserial primary key,
  lead_id uuid not null references public.leads(id) on delete cascade,
  created_at timestamptz not null default now(),
  message text not null,
  actor text default 'system'
);
create index if not exists lead_events_lead_idx on public.lead_events (lead_id, created_at);

-- ---------- Tilbud med egen URL (logomarketing.dk/t/?k=KODE) ----------
create table if not exists public.quotes (
  code text primary key,                 -- kort, ugætbar kode
  lead_id uuid references public.leads(id) on delete set null,
  created_at timestamptz not null default now(),
  valid_until date,
  org text not null,
  contact_name text,
  intro text,                            -- personlig tekst øverst
  lines jsonb not null default '[]',     -- [{"title":"3×3 telt, tag + bagvæg","qty":1,"unit":4999}]
  shipping numeric default 0,
  delivery_text text,                    -- "Typisk 4–6 uger efter godkendt korrektur"
  mockup_url text,                       -- link til mockup-billede (Supabase Storage eller ekstern)
  status text not null default 'sendt' check (status in ('kladde','sendt','set','accepteret','afvist','udloebet')),
  accepted_at timestamptz,
  accepted_by text,
  seen_at timestamptz
);

-- updated_at automatik
create or replace function public.touch_updated_at() returns trigger language plpgsql as $$
begin new.updated_at = now(); return new; end $$;
drop trigger if exists leads_touch on public.leads;
create trigger leads_touch before update on public.leads for each row execute function public.touch_updated_at();

-- Log automatisk når et lead oprettes / skifter status
create or replace function public.log_lead_change() returns trigger language plpgsql security definer as $$
begin
  if tg_op = 'INSERT' then
    insert into public.lead_events (lead_id, message, actor) values (new.id, 'Forespørgsel modtaget via ' || coalesce(new.source,'web'), 'system');
  elsif tg_op = 'UPDATE' and new.stage is distinct from old.stage then
    insert into public.lead_events (lead_id, message, actor) values (new.id, 'Status ændret til ' || new.stage, coalesce(auth.jwt() ->> 'email','system'));
  end if;
  return new;
end $$;
drop trigger if exists leads_log on public.leads;
create trigger leads_log after insert or update on public.leads for each row execute function public.log_lead_change();

-- ---------- Sikkerhed (RLS) ----------
alter table public.leads enable row level security;
alter table public.lead_events enable row level security;
alter table public.quotes enable row level security;
alter table public.admins enable row level security;

-- Alle (anon) må OPRETTE et lead – det er formularen. Ingen andre må læse dem.
drop policy if exists "anon can insert lead" on public.leads;
create policy "anon can insert lead" on public.leads for insert to anon, authenticated with check (true);
-- Formularen må opdatere logo_path på det lead, den lige har oprettet (kun den kolonne, kun kort tid efter)
drop policy if exists "anon can set logo shortly after" on public.leads;
create policy "anon can set logo shortly after" on public.leads for update to anon
  using (created_at > now() - interval '10 minutes') with check (created_at > now() - interval '10 minutes');

-- Admin må alt
drop policy if exists "admin all leads" on public.leads;
create policy "admin all leads" on public.leads for all to authenticated using (public.is_admin()) with check (public.is_admin());
drop policy if exists "admin all events" on public.lead_events;
create policy "admin all events" on public.lead_events for all to authenticated using (public.is_admin()) with check (public.is_admin());
drop policy if exists "admin all quotes" on public.quotes;
create policy "admin all quotes" on public.quotes for all to authenticated using (public.is_admin()) with check (public.is_admin());
drop policy if exists "admin read admins" on public.admins;
create policy "admin read admins" on public.admins for select to authenticated using (public.is_admin());

-- Kunden må se SIT tilbud via koden (koden er ugætbar – 10 tilfældige tegn)
drop policy if exists "anyone with code can read quote" on public.quotes;
create policy "anyone with code can read quote" on public.quotes for select to anon, authenticated using (true);

-- Kunden accepterer via en funktion (så de ikke kan ændre andet end status)
create or replace function public.accept_quote(p_code text, p_name text)
returns json language plpgsql security definer set search_path = public as $$
declare q public.quotes;
begin
  select * into q from public.quotes where code = p_code;
  if q.code is null then return json_build_object('ok', false, 'error', 'Tilbuddet findes ikke'); end if;
  if q.status in ('accepteret') then return json_build_object('ok', true, 'already', true); end if;
  if q.valid_until is not null and q.valid_until < current_date then return json_build_object('ok', false, 'error', 'Tilbuddet er udløbet – skriv til os, så fornyer vi det'); end if;
  update public.quotes set status = 'accepteret', accepted_at = now(), accepted_by = p_name where code = p_code;
  if q.lead_id is not null then
    update public.leads set stage = 'vundet' where id = q.lead_id;
    insert into public.lead_events (lead_id, message, actor) values (q.lead_id, 'Tilbud ' || p_code || ' accepteret af ' || coalesce(p_name,'kunden'), 'kunde');
  end if;
  return json_build_object('ok', true);
end $$;
grant execute on function public.accept_quote(text, text) to anon, authenticated;

-- Marker tilbud som "set" første gang det åbnes
create or replace function public.mark_quote_seen(p_code text)
returns void language sql security definer set search_path = public as $$
  update public.quotes set seen_at = coalesce(seen_at, now()), status = case when status = 'sendt' then 'set' else status end where code = p_code;
$$;
grant execute on function public.mark_quote_seen(text) to anon, authenticated;

-- ---------- Storage: bucket til logoer ----------
insert into storage.buckets (id, name, public) values ('logos', 'logos', false) on conflict (id) do nothing;
drop policy if exists "anon upload logo" on storage.objects;
create policy "anon upload logo" on storage.objects for insert to anon, authenticated with check (bucket_id = 'logos');
drop policy if exists "admin read logos" on storage.objects;
create policy "admin read logos" on storage.objects for select to authenticated using (bucket_id = 'logos' and public.is_admin());
drop policy if exists "admin delete logos" on storage.objects;
create policy "admin delete logos" on storage.objects for delete to authenticated using (bucket_id = 'logos' and public.is_admin());

-- Bucket til mockups (offentlig læsning – linkes fra tilbudssiden)
insert into storage.buckets (id, name, public) values ('mockups', 'mockups', true) on conflict (id) do nothing;
drop policy if exists "public read mockups" on storage.objects;
create policy "public read mockups" on storage.objects for select to anon, authenticated using (bucket_id = 'mockups');
drop policy if exists "admin write mockups" on storage.objects;
create policy "admin write mockups" on storage.objects for insert to authenticated with check (bucket_id = 'mockups' and public.is_admin());

-- Færdig. Næste: Database → Webhooks → ny webhook på public.leads (INSERT) → Edge Function notify-lead.
