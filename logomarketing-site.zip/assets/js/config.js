// ============================================================
//  LogoMarketing – konfiguration
//  Udfyld de to værdier fra Supabase → Project Settings → API.
//  "anon"-nøglen er lavet til at ligge offentligt i browseren –
//  sikkerheden ligger i databasens RLS-regler (se supabase/schema.sql).
// ============================================================
window.LM_CONFIG = {
  SUPABASE_URL: "https://DIT-PROJEKT.supabase.co",
  SUPABASE_ANON_KEY: "INDSÆT-ANON-KEY",
  ADMIN_EMAIL: "info@logomarketing.dk",
};

(function () {
  if (window.supabase && window.LM_CONFIG.SUPABASE_URL.indexOf("DIT-PROJEKT") === -1) {
    window.LM_SUPABASE = window.supabase.createClient(window.LM_CONFIG.SUPABASE_URL, window.LM_CONFIG.SUPABASE_ANON_KEY);
  } else {
    console.warn("LogoMarketing: Supabase er ikke konfigureret endnu – ret assets/js/config.js");
  }
})();
