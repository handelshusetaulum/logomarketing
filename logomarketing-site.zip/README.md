# logomarketing.dk

Statisk site (HTML/CSS/JS) + Supabase (database, login, filer) + Resend (mail). Hostes på Cloudflare Pages.

Start her: **OPSÆTNING.md**

- `index.html` – hele sitet (forside, telte, dogtags, merchandise, foreninger, vilkår) med hash-routing
- `admin.html` – CRM (kræver login)
- `t/` – tilbudsside pr. kunde (`/t/?k=KODE`)
- `supabase/` – databaseskema og edge function til mails
